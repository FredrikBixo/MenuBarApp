//
//  AccountsCell.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-02-20.
//

#import <Cocoa/Cocoa.h>

@interface AccountsCell : NSTableCellView

@property (assign) IBOutlet NSTextField *secondTextField5;

@end
