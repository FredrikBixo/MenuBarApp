//
//  AccountsCell.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-02-20.
//

#import "AccountsCell.h"

@implementation AccountsCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
