//
//  CurrencyCell.h
//  
//
//  Created by Fredrik Bixo on 2018-01-24.
//

#import <Cocoa/Cocoa.h>

@interface CurrencyCell : NSTableCellView

@end
