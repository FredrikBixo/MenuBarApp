//
//  CustomVC3.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-25.
//

#import <Cocoa/Cocoa.h>

@interface CustomVC3 : NSViewController

@end
