//
//  CustomVC3.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-25.
//

#import "CustomVC3.h"

@interface CustomVC3 ()

@end

@implementation CustomVC3

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

-(void)awakeFromNib{
    NSLog(@"ddue");
}

@end
