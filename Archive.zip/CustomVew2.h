//
//  CustomVew2.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-30.
//

#import <Cocoa/Cocoa.h>

@interface CustomVew2 : NSView

@end
