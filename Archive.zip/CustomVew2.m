//
//  CustomVew2.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-30.
//

#import "CustomVew2.h"

@implementation CustomVew2

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
