//
//  CurrencyCell.m
//  
//
//  Created by Fredrik Bixo on 2018-01-24.
//

#import "CurrencyCell.h"

@implementation CurrencyCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}


@end
