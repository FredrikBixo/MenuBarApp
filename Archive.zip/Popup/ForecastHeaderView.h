//
//  ForecastHeaderView.h
//  
//
//  Created by Fredrik Bixo on 2018-01-22.
//

#import <Cocoa/Cocoa.h>

@interface ForecastHeaderView : NSTableHeaderView

@end
