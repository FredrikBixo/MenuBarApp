//
//  HoldingCells.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-24.
//

#import <Cocoa/Cocoa.h>

@interface HoldingCell : NSTableCellView

@property (assign) IBOutlet NSTextField *secondTextField;

@property (assign) IBOutlet NSTextField *secondTextField2;

@end
