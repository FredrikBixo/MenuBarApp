//
//  HoldingCells.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-24.
//

#import "HoldingCell.h"

@implementation HoldingCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}


@end
