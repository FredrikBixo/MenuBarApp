@interface Panel : NSPanel
@end
