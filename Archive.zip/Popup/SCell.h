//
//  SCell.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-02-19.
//

#import <Cocoa/Cocoa.h>

@interface SCell : NSTableCellView

@property (assign) IBOutlet NSTextField *secondTextField1;
@property (weak) IBOutlet NSImageView *btc1;

@end
