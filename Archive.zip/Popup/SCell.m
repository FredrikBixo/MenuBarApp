//
//  SCell.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-02-19.
//

#import "SCell.h"

@implementation SCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
