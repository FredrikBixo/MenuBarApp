//
//  SearchCell.h
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-30.
//

#import <Cocoa/Cocoa.h>

@interface SearchCell : NSTableCellView

@property (assign) IBOutlet NSTextField *secondTextField;
@property (weak) IBOutlet NSImageView *btc;


@end
