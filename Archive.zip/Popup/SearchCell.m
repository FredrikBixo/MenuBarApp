//
//  SearchCell.m
//  Popup
//
//  Created by Fredrik Bixo on 2018-01-30.
//

#import "SearchCell.h"

@implementation SearchCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    
    // Drawing code here.
}

@end
