# Popup

Popup project is a demo with custom popover window appearing from the icon in the Mac OS X status bar.

# License

Popup is licensed under the BSD license.